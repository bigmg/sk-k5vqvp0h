"""เช็คว่าเครื่องพร้อมทำคลิปหรือยัง
ใช้: python tools/check_setup.py
"""
import importlib, os, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import env, ROOT

ok = True
def line(state, name, note=""):
    global ok
    mark = {"ok": "✅", "warn": "⚠️ ", "bad": "❌"}[state]
    if state == "bad":
        ok = False
    print(f"{mark} {name}" + (f"  — {note}" if note else ""))

print("== ระดับ 1: ต้องมี ==")
line("ok" if sys.version_info >= (3, 10) else "bad", f"Python {sys.version.split()[0]}", "" if sys.version_info >= (3, 10) else "ต้อง 3.10 ขึ้นไป")
for cmd, hint in [("ffmpeg", "winget install Gyan.FFmpeg  /  brew install ffmpeg"),
                  ("ffprobe", "มากับ ffmpeg"),
                  ("yt-dlp", "pip install -U yt-dlp")]:
    line("ok" if shutil.which(cmd) else "bad", cmd, "" if shutil.which(cmd) else hint)
line("ok" if env("GEMINI_API_KEY") else "bad", "GEMINI_API_KEY ใน .env",
     "" if env("GEMINI_API_KEY") else "ขอที่ https://aistudio.google.com/apikey แล้วใส่ใน .env")
fonts = [f for f in os.listdir(os.path.join(ROOT, "fonts")) if f.lower().endswith((".ttf", ".otf"))] if os.path.isdir(os.path.join(ROOT, "fonts")) else []
line("ok" if fonts else "bad", "ฟอนต์ซับในโฟลเดอร์ fonts/", ", ".join(fonts) if fonts else "โหลดฟอนต์ไทย (เช่น Kanit Bold) จาก Google Fonts มาวาง")
music = [f for f in os.listdir(os.path.join(ROOT, "music")) if f.lower().endswith((".mp3", ".wav", ".m4a"))] if os.path.isdir(os.path.join(ROOT, "music")) else []
line("ok" if music else "warn", "เพลงในโฟลเดอร์ music/", f"{len(music)} ไฟล์" if music else "ยังไม่มี (ทำคลิปได้ แต่จะไม่มีเพลงคลอ)")

print("\n== ระดับ 2: เสริม ==")
try:
    importlib.import_module("faster_whisper")
    line("ok", "faster-whisper (ถอดเสียง/จับเวลาซับ)")
except Exception:
    line("warn", "faster-whisper", "pip install faster-whisper  (ไม่มีก็ได้ ซับจะกระจายเวลาตามความยาวคำแทน)")
try:
    import torch
    line("ok" if torch.cuda.is_available() else "warn", "การ์ดจอ NVIDIA (CUDA)",
         "" if torch.cuda.is_available() else "ไม่มี/ไม่เจอ → ถอดเสียงด้วย CPU ช้ากว่าหลายเท่า")
except Exception:
    line("warn", "PyTorch/CUDA", "ไม่ได้ติดตั้ง (ไม่บังคับ)")
line("ok" if env("PEXELS_API_KEY") else "warn", "PEXELS_API_KEY", "" if env("PEXELS_API_KEY") else "ไม่บังคับ — สมัครฟรีที่ https://www.pexels.com/api/")

print("\nพร้อมทำคลิปแล้ว 🎬" if ok else "\nยังขาดของ ❌ ด้านบน — บอก Claude ว่า 'ช่วยติดตั้งตัวที่ขาด' ได้เลย")
