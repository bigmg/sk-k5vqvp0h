"""ประกอบคลิปแนวตั้ง 1080×1920 จาก shots.json + เสียงพากย์ + ซับ + เพลง
ใช้:  python tools/build_short.py clips/<คลิป>
      python tools/build_short.py --preview styles/แบบA.json      → ภาพตัวอย่างซับ (ใช้ตอนเลือกสไตล์ช่อง)
ต้องมี: style.json (หน้าตาช่อง — ดู STYLE.md) · clips/<คลิป>/shots.json · vo/vo.wav · caps_timed.json
ได้:   clips/<คลิป>/out/<คลิป>.mp4

shots.json:
{
  "music": "music/เพลง.mp3",          (ไม่ใส่ = ไม่มีเพลง)
  "shots": [
    {"src": "source/a.mp4", "start": 12.5, "dur": 3.0, "mode": "crop", "cx": 0.5, "credit": "ภาพ: ชื่อช่อง"},
    {"src": "source/b.jpg", "dur": 2.0, "mode": "fit"},
    {"src": "source/scene01.png", "dur": 4.0, "mode": "crop", "move": "in", "amount": 0.08}
  ]
}
mode: crop = เต็มจอ ตัดซ้ายขวา (cx 0–1 = จุดกึ่งกลางที่จะเก็บไว้) · fit = ภาพเต็มกว้าง บนพื้นหลังเบลอ
move: in / out = ซูมเข้า/ออกช้าๆ (ภาพนิ่ง AI หรือภาพประกอบ) · ไม่ใส่ = นิ่ง
ซับและเครดิตเรนเดอร์ด้วย libass (ของ ffmpeg) → สระ/วรรณยุกต์ไทยวางถูกตำแหน่ง
"""
import json, os, re, shutil, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import ROOT, duration, need, run

W, H, FPS = 1080, 1920, 30
need("ffmpeg"); need("ffprobe")


def rel(p):
    """path แบบสัมพัทธ์จาก ROOT ใช้ / (ffmpeg filter ไม่ชอบ C:\\ และ :)"""
    return os.path.relpath(p, ROOT).replace("\\", "/")


def ass_color(hexstr):
    """#RRGGBB หรือ #RRGGBBAA (AA=ความทึบ) → &HAABBGGRR"""
    h = hexstr.lstrip("#"); r, g, b = h[0:2], h[2:4], h[4:6]
    a = 255 - int(h[6:8], 16) if len(h) == 8 else 0
    return f"&H{a:02X}{b}{g}{r}".upper()


def load_style(path):
    if not os.path.exists(path):
        raise SystemExit("ยังไม่มี style.json (หน้าตาช่อง)\n→ บอก Claude ว่า \"ช่วยออกแบบสไตล์ช่อง\" ก่อนทำคลิปแรก (ดู STYLE.md)")
    st = json.load(open(path, encoding="utf-8"))
    for k in ("font_name", "size", "text_color", "highlight_color", "y"):
        if k not in st:
            raise SystemExit(f"style ขาดค่า '{k}' (ดู STYLE.md)")
    return st


def caption_text(t, st):
    hi, base = ass_color(st["highlight_color"]), ass_color(st["text_color"])
    t = t.replace("{", "(").replace("}", ")")
    t = re.sub(r"\[(.+?)\]", lambda m: "{\\c" + hi + "}" + m.group(1) + "{\\c" + base + "}", t)
    return t.replace("\\n", "\\N")


def write_ass(path, st, caps, credits):
    box = st.get("box", False)
    cap_style = ",".join(map(str, [
        "Cap", st["font_name"], st["size"], ass_color(st["text_color"]), ass_color(st["text_color"]),
        ass_color(st.get("box_color" if box else "outline_color", "#000000")), ass_color(st.get("shadow_color", "#00000080")),
        -1 if st.get("bold", True) else 0, 0, 0, 0, 100, 100, st.get("spacing", 0), 0,
        3 if box else 1, st.get("box_padding", 12) if box else st.get("outline", 5), st.get("shadow", 0),
        5, 60, 60, 0, 1]))
    cr = st.get("credit", {})
    cr_style = ",".join(map(str, [
        "Credit", cr.get("font_name", st["font_name"]), cr.get("size", 32), ass_color(cr.get("color", "#FFFFFFCC")),
        ass_color("#FFFFFF"), ass_color("#00000099"), ass_color("#00000000"), 0, 0, 0, 0, 100, 100, 0, 0,
        1, 2, 0, 5, 40, 40, 0, 1]))
    ts = lambda s: f"{int(s // 3600)}:{int(s % 3600 // 60):02d}:{s % 60:05.2f}"
    cy, cry = st["y"], cr.get("y", 110)
    L = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}", "WrapStyle: 0", "",
         "[V4+ Styles]",
         "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, "
         "Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
         "Style: " + cap_style, "Style: " + cr_style, "", "[Events]",
         "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"]
    fade = st.get("fade_ms", 0)
    for c in caps:
        fx = f"{{\\pos({W // 2},{cy})" + (f"\\fad({fade},0)" if fade else "") + "}"
        L.append(f"Dialogue: 0,{ts(c['start'])},{ts(c['end'])},Cap,,0,0,0,,{fx}{caption_text(c['text'], st)}")
    for s, e, t in credits:
        L.append(f"Dialogue: 1,{ts(s)},{ts(e)},Credit,,0,0,0,,{{\\pos({W // 2},{cry})}}{t}")
    open(path, "w", encoding="utf-8").write("\n".join(L) + "\n")


def subs_filter(ass):
    fonts = os.path.join(ROOT, "fonts")
    return f"ass='{rel(ass)}':shaping=complex" + (f":fontsdir='{rel(fonts)}'" if os.path.isdir(fonts) else "")


# ---------- โหมดพรีวิวสไตล์ ----------
if "--preview" in sys.argv:
    sp = os.path.abspath(sys.argv[sys.argv.index("--preview") + 1]); st = load_style(sp)
    sample = st.get("preview_text", "หนุ่มอเมริกันกินทั้งวันในไทย\\Nใช้แค่ [280 บาท]")
    tmp = tempfile.mkdtemp(dir=ROOT)
    ass = os.path.join(tmp, "p.ass"); write_ass(ass, st, [{"start": 0, "end": 5, "text": sample}], [(0, 5, "ภาพ: ตัวอย่างเครดิต")])
    bg = st.get("preview_bg")  # ใส่ path ภาพจริงเพื่อดูบนภาพจริงได้
    src = ["-i", bg] if bg else ["-f", "lavfi", "-i", f"gradients=s={W}x{H}:c0=0x3a6073:c1=0xc8a165:n=2"]
    out = os.path.splitext(sp)[0] + "_preview.png"
    run(["ffmpeg", "-y", "-loglevel", "error", *src, "-vf",
         f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},loop=-1:1,fps=10," + subs_filter(ass), "-ss", "1", "-frames:v", "1", out], cwd=ROOT)
    shutil.rmtree(tmp); print("✓", out); sys.exit()

# ---------- ประกอบคลิป ----------
clip = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else sys.exit(__doc__)
name = os.path.basename(clip.rstrip("/\\"))
st = load_style(os.path.join(ROOT, "style.json"))
cfg = json.load(open(os.path.join(clip, "shots.json"), encoding="utf-8"))
vo = os.path.join(clip, "vo", "vo.wav")
caps = json.load(open(os.path.join(clip, "caps_timed.json"), encoding="utf-8"))
total = round(duration(vo) + cfg.get("end_pad", 0.6), 2)
os.makedirs(os.path.join(clip, "out"), exist_ok=True)
tmp = tempfile.mkdtemp(dir=os.path.join(clip, "out"))

# 1) ตัดช็อต ให้ความยาวรวม = ความยาวเสียง
shots, t, segs, credits = cfg["shots"], 0.0, [], []
for i, s in enumerate(shots):
    if t >= total - 0.05:
        break
    dur = s["dur"] if i < len(shots) - 1 else max(s["dur"], total - t)
    dur = min(dur, total - t)
    src = os.path.join(clip, s["src"]); is_img = src.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
    inp = (["-loop", "1", "-t", f"{dur}", "-i", src] if is_img else
           ["-ss", f"{s.get('start', 0)}", "-t", f"{dur}", "-i", src])
    if s.get("mode", "crop") == "fit":
        vf = (f"split[a][b];[a]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},boxblur=30:2,eq=brightness=-0.08[bg];"
              f"[b]scale={W}:-2[fg];[bg][fg]overlay=0:(H-h)/2")
    else:
        cx = s.get("cx", 0.5)
        vf = (f"scale={W}:{H}:force_original_aspect_ratio=increase,"
              f"crop={W}:{H}:x='min(max(0,iw*{cx}-{W}/2),iw-{W})':y='(ih-{H})/2'")
    if s.get("move") in ("in", "out"):   # ซูมช้าๆ (เหมาะกับภาพนิ่งในคลิปเล่าเรื่อง) · amount = ซูมรวมทั้งช็อต
        amt = s.get("amount", 0.08)
        z = f"(1+{amt}*t/{dur})" if s["move"] == "in" else f"(1+{amt}*(1-t/{dur}))"
        vf += (f",fps={FPS},scale=w='trunc({W}*{z}/2)*2':h='trunc({H}*{z}/2)*2':eval=frame:flags=bicubic,"
               f"crop={W}:{H}")
    seg = os.path.join(tmp, f"s{i:03d}.mp4")
    run(["ffmpeg", "-y", "-loglevel", "error", *inp, "-filter_complex", f"[0:v]{vf},fps={FPS},setsar=1,format=yuv420p,tpad=stop_mode=clone:stop_duration=5[v]",
         "-map", "[v]", "-t", f"{dur}", "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", seg])
    segs.append(seg)
    if s.get("credit"):
        credits.append((t, t + dur, s["credit"]))
    t += dur
if t < total - 0.05:
    print(f"⚠️ ช็อตรวม {t:.1f} วิ สั้นกว่าเสียง {total:.1f} วิ — ช็อตสุดท้ายถูกยืด เพิ่มช็อตใน shots.json จะดีกว่า")
lst = os.path.join(tmp, "list.txt")
open(lst, "w", encoding="utf-8").write("".join(f"file '{os.path.basename(p)}'\n" for p in segs))
body = os.path.join(tmp, "body.mp4")
run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", "list.txt", "-c", "copy", "body.mp4"], cwd=tmp)

# 2) ซับ + เครดิต
ass = os.path.join(tmp, "caps.ass"); write_ass(ass, st, caps, credits)

# 3) เสียง: พากย์ปรับดังมาตรฐาน · เพลงตั้งระดับเฉลี่ยตาม music_db (ค่าตั้งต้น −26 dB) แล้วค่อยๆ เบาตอนจบ
inputs = ["-i", body, "-i", vo]; af = f"[1:a]loudnorm=I=-15:TP=-1.5:LRA=11,apad[vo]"
music = cfg.get("music")
if music:
    mp = os.path.join(ROOT, music)
    r = subprocess.run(["ffmpeg", "-i", mp, "-af", "volumedetect", "-f", "null", "-"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    mean = float(re.search(r"mean_volume: (-?[\d.]+)", r.stderr).group(1))
    gain = cfg.get("music_db", -26) - mean
    inputs += ["-stream_loop", "-1", "-i", mp]
    af += (f";[2:a]volume={gain:.1f}dB,afade=t=in:d=0.5,afade=t=out:st={max(0, total - 1.5)}:d=1.5[bg];"
           f"[vo][bg]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.95[a]")
else:
    af += ";[vo]anull[a]"

# 4) โลโก้ (ถ้า style มี) + รวมทุกอย่าง
vf = f"[0:v]{subs_filter(ass)}[v0]"
logo = st.get("logo")
if logo and os.path.exists(os.path.join(ROOT, logo["file"])):
    inputs += ["-i", os.path.join(ROOT, logo["file"])]
    li = inputs.count("-i") - 1
    when = "+".join(f"between(t,{a},{a + b})" for a, b in logo.get("show", [[0, total]]))
    vf += f";[{li}:v]scale={logo.get('width', 160)}:-1[lg];[v0][lg]overlay={logo.get('x', 40)}:{logo.get('y', 40)}:enable='{when}'[v1]"
    vlabel = "[v1]"
else:
    vlabel = "[v0]"
out = os.path.join(clip, "out", f"{name}.mp4")
run(["ffmpeg", "-y", "-loglevel", "error", *inputs, "-filter_complex", f"{vf};{af}", "-map", vlabel, "-map", "[a]",
     "-t", f"{total}", "-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p",
     "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out], cwd=ROOT)
shutil.rmtree(tmp)
print(f"✓ {out}  ({total:.1f} วิ)")
