"""หาคลิป YouTube ที่ติด Creative Commons แล้วเช็ค license ทีละคลิป (ฟิลเตอร์ของ YouTube ไม่แม่น ต้องเช็คซ้ำ)
ใช้:  python tools/find_cc.py "street food bangkok" "thailand 7-eleven" --min 100000 --years 5
      python tools/find_cc.py --check https://www.youtube.com/watch?v=XXXX
ผล: ตารางวิว · ปี · ช่อง · ชื่อ · ลิงก์ (เฉพาะที่ license = Creative Commons จริง)
⚠️ ผ่านตัวนี้แล้วยังต้องดูเองว่า "เจ้าของถ่ายเอง" ไม่ใช่เอาคลิปคนอื่นมาอัป
"""
import datetime as dt, json, os, subprocess, sys, urllib.parse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import need

need("yt-dlp")
args = sys.argv[1:]
def opt(k, d):
    return int(args[args.index(k) + 1]) if k in args else d
MIN, YEARS, PER = opt("--min", 100000), opt("--years", 5), opt("--per", 20)


def info(url):
    r = subprocess.run(["yt-dlp", "--skip-download", "--no-warnings", "--print",
                        "%(license)s\t%(upload_date)s\t%(view_count)s\t%(channel)s\t%(duration)s\t%(title)s\t%(webpage_url)s", url],
                       capture_output=True, text=True, encoding="utf-8")
    parts = r.stdout.strip().split("\t")
    return parts if len(parts) == 7 else None


if "--check" in args:
    for u in [a for a in args if a.startswith("http")]:
        p = info(u)
        print(p if p else f"อ่านไม่ได้: {u}")
    sys.exit()

cutoff = (dt.date.today() - dt.timedelta(days=365 * YEARS)).strftime("%Y%m%d")
queries = [a for i, a in enumerate(args) if not a.startswith("--") and (i == 0 or not args[i - 1].startswith("--"))]
seen, rows = set(), []
for q in queries:
    # sp=CAMSAjAB = เรียงตามยอดวิว + Creative Commons
    url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote(q) + "&sp=CAMSAjAB"
    r = subprocess.run(["yt-dlp", "--flat-playlist", "--no-warnings", "--playlist-end", str(PER),
                        "--print", "%(id)s", url], capture_output=True, text=True, encoding="utf-8")
    for vid in r.stdout.split():
        if vid in seen:
            continue
        seen.add(vid)
        p = info("https://www.youtube.com/watch?v=" + vid)
        if not p:
            continue
        lic, date, views, ch, dur, title, link = p
        if "Creative Commons" not in lic or "ShareAlike" in lic:
            continue
        if date < cutoff or int(views or 0) < MIN:
            continue
        rows.append((int(views), date[:4], ch, int(float(dur or 0)), title, link))
        print(f"  ✓ {int(views):>10,}  {date[:4]}  {ch[:24]:<24} {title[:60]}")

rows.sort(reverse=True)
print(f"\nเจอ {len(rows)} คลิป (CC BY · ≥{MIN:,} วิว · ไม่เกิน {YEARS} ปี)\n")
print("| วิว | ปี | ยาว(วิ) | ช่อง | ชื่อ | ลิงก์ |\n|---|---|---|---|---|---|")
for v, y, ch, d, t, l in rows:
    print(f"| {v:,} | {y} | {d} | {ch} | {t} | {l} |")
