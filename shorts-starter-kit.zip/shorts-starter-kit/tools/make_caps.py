"""จับเวลาซับให้ตรงเสียงพากย์
ใช้: python tools/make_caps.py clips/<คลิป>
อ่าน: caps.txt (บรรทัดละ 1 ก้อนซับ · [คำ] = คำเน้น) + vo/vo.wav
ได้: caps_timed.json  [{"start":..,"end":..,"text":..}]  — แก้เวลาด้วยมือได้ถ้าต้องการ
วิธี: มี faster-whisper → ใช้เวลาของคำจริงในเสียง · ไม่มี → หาช่วงที่มีเสียงพูดแล้วกระจายตามความยาวตัวอักษร
"""
import json, os, re, sys, wave, array
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _common  # noqa: F401

clip = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else sys.exit(__doc__)
lines = [l.strip() for l in open(os.path.join(clip, "caps.txt"), encoding="utf-8") if l.strip()]
vo = os.path.join(clip, "vo", "vo.wav")


def weight(s):
    """น้ำหนักเวลาพูดโดยประมาณ: ตัวเลข 1 หลักพูดยาวกว่าตัวอักษร 1 ตัว"""
    s = re.sub(r"[\[\]\s]", "", s)
    return sum(2.5 if ch.isdigit() else (0 if ch in "่้๊๋ิีึืุู็์ั" else 1) for ch in s) or 1


def speech_bounds(path):
    w = wave.open(path); rate = w.getframerate(); a = array.array("h", w.readframes(w.getnframes()))
    hop = rate // 50
    loud = [i * hop / rate for i in range(len(a) // hop) if max(abs(x) for x in a[i * hop:(i + 1) * hop]) > 800]
    return (loud[0], loud[-1] + 0.02) if loud else (0, len(a) / rate)


timeline = None  # [(t, น้ำหนักสะสม)]
try:
    import torch  # noqa: F401  (ให้ CUDA dll โหลดก่อน)
    from faster_whisper import WhisperModel
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    m = WhisperModel("large-v3" if dev == "cuda" else "small", device=dev,
                     compute_type="float16" if dev == "cuda" else "int8")
    segs, _ = m.transcribe(vo, language="th", word_timestamps=True)
    words = [(x.start, x.end, x.word) for s in segs for x in s.words]
    acc, timeline = 0.0, [(words[0][0], 0.0)] if words else None
    for st, en, wd in words:
        acc += weight(wd); timeline.append((en, acc))
    if len(words) < 3:
        raise ValueError("ถอดคำได้น้อยเกินไป")
    print(f"ใช้เวลาคำจากเสียงจริง ({len(words)} คำ)")
except Exception as e:
    print(f"ไม่ใช้ whisper ({type(e).__name__}) → กระจายตามความยาวตัวอักษร")

if not timeline:
    a, b = speech_bounds(vo)
    timeline = [(a, 0.0), (b, 1.0)]

total_w = timeline[-1][1]
cap_w = [weight(l) for l in lines]; scale = total_w / sum(cap_w)


def at(wpos):
    for (t0, w0), (t1, w1) in zip(timeline, timeline[1:]):
        if wpos <= w1:
            return t0 + (t1 - t0) * ((wpos - w0) / (w1 - w0) if w1 > w0 else 0)
    return timeline[-1][0]


out, cum = [], 0.0
for l, w in zip(lines, cap_w):
    s, cum = at(cum), cum + w * scale
    out.append({"start": round(s, 2), "end": round(at(cum), 2), "text": l})
for i in range(len(out) - 1):            # ให้ซับต่อกันไม่มีช่องว่างกะพริบ
    out[i]["end"] = out[i + 1]["start"]
json.dump(out, open(os.path.join(clip, "caps_timed.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for c in out:
    print(f'{c["start"]:6.2f}–{c["end"]:6.2f}  {c["text"]}')
print("✓ caps_timed.json")
