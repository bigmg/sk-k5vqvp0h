"""ถอดเสียงคลิปต้นทาง (หรือเสียงพากย์) เป็นข้อความพร้อมเวลา
ใช้: python tools/transcribe.py clips/<คลิป>/source/video.mp4 [--lang en] [--model large-v3]
ผล: ไฟล์ .txt ข้างๆ ต้นฉบับ (บรรทัดละช่วง [mm:ss] ข้อความ)
ต้องมี: pip install faster-whisper  · มีการ์ดจอ NVIDIA จะเร็วมาก ไม่มีก็ใช้ CPU ได้แต่ช้า
⚠️ ตัวเลขที่ถอดได้ผิดบ่อย — เช็คกับภาพจริงก่อนเขียนลงบท
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _common  # noqa: F401  (ตั้ง UTF-8)

args = sys.argv[1:]
if not args:
    raise SystemExit(__doc__)
src = args[0]
lang = args[args.index("--lang") + 1] if "--lang" in args else None
size = args[args.index("--model") + 1] if "--model" in args else "large-v3"
try:
    import torch
    dev = "cuda" if torch.cuda.is_available() else "cpu"
except Exception:
    dev = "cpu"
from faster_whisper import WhisperModel
if dev == "cpu" and size == "large-v3":
    size = "small"; print("ไม่มี GPU → ใช้รุ่น small (เร็วกว่า แม่นน้อยกว่า)")
m = WhisperModel(size, device=dev, compute_type="float16" if dev == "cuda" else "int8")
segs, info = m.transcribe(src, language=lang, vad_filter=True)
out = os.path.splitext(src)[0] + ".txt"
with open(out, "w", encoding="utf-8") as f:
    for s in segs:
        line = f"[{int(s.start // 60):02d}:{s.start % 60:05.2f}] {s.text.strip()}"
        print(line); f.write(line + "\n")
print(f"\n✓ {out}  (ภาษา {info.language})")
