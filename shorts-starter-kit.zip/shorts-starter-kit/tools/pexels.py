"""ค้น/โหลดคลิปสต็อกแนวตั้งจาก Pexels (ฟรี ใช้เชิงพาณิชย์ได้)
ใช้:  python tools/pexels.py search "street food night market"
      python tools/pexels.py get <id> clips/<คลิป>/source/pexels_<id>.mp4
ต้องมี PEXELS_API_KEY ใน .env · ใช้เป็นภาพเสริมเท่านั้น ต้องตรงทั้งสิ่งที่เห็นและอารมณ์ของประโยค
"""
import json, os, sys, urllib.parse, urllib.request
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import env

KEY = env("PEXELS_API_KEY") or sys.exit("ไม่พบ PEXELS_API_KEY ใน .env")


def api(url):
    req = urllib.request.Request(url, headers={"Authorization": KEY, "User-Agent": "Mozilla/5.0"})
    return json.load(urllib.request.urlopen(req, timeout=60))


a = sys.argv[1:]
if a[:1] == ["search"]:
    d = api("https://api.pexels.com/videos/search?per_page=10&orientation=portrait&query=" + urllib.parse.quote(" ".join(a[1:])))
    for v in d.get("videos", []):
        print(f'id={v["id"]:<10} {v["width"]}x{v["height"]} {v["duration"]:>3}s  {v["url"]}')
elif a[:1] == ["get"] and len(a) == 3:
    v = api(f"https://api.pexels.com/videos/videos/{a[1]}")
    f = max((f for f in v["video_files"] if (f.get("height") or 0) <= 1920), key=lambda f: f.get("height") or 0)
    os.makedirs(os.path.dirname(os.path.abspath(a[2])), exist_ok=True)
    req = urllib.request.Request(f["link"], headers={"User-Agent": "Mozilla/5.0"})
    open(a[2], "wb").write(urllib.request.urlopen(req, timeout=300).read())
    print("✓", a[2], f'{f["width"]}x{f["height"]}')
else:
    print(__doc__)
