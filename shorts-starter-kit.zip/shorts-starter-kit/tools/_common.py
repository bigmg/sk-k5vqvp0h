"""ของใช้ร่วม: อ่าน .env · หา ffmpeg · ตั้ง stdout เป็น UTF-8 (กันภาษาไทยพังบน Windows)"""
import os, sys, shutil, subprocess, json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def env(name, default=None):
    """อ่านค่าจากตัวแปรระบบก่อน ไม่มีค่อยอ่านจาก .env ที่โฟลเดอร์หลัก"""
    if os.environ.get(name):
        return os.environ[name]
    p = os.path.join(ROOT, ".env")
    if os.path.exists(p):
        for line in open(p, encoding="utf-8"):
            line = line.strip()
            if line.startswith(name + "="):
                v = line.split("=", 1)[1].strip().strip('"').strip("'")
                if v:
                    return v
    return default


def need(cmd):
    if not shutil.which(cmd):
        raise SystemExit(f"ไม่พบโปรแกรม '{cmd}' — ติดตั้งก่อน (ดู README) แล้วเปิด VS Code ใหม่")


def run(args, **kw):
    return subprocess.run(args, check=True, **kw)


def duration(path):
    need("ffprobe")
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                          "-of", "json", path], capture_output=True, text=True, check=True).stdout
    return float(json.loads(out)["format"]["duration"])
