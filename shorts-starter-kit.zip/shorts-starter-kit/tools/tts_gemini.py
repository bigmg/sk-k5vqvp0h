"""เจนเสียงพากย์จาก script.txt ด้วย Gemini TTS
ใช้:  python tools/tts_gemini.py clips/<คลิป>                 → clips/<คลิป>/vo/vo.wav
      python tools/tts_gemini.py clips/a clips/b clips/c     → เจนรวมครั้งเดียว (ประหยัดโควตา) แล้วหั่นตามช่วงเงียบ
ตั้งค่าใน .env:  GEMINI_API_KEY=...   TTS_MODEL=gemini-3.8-flash-tts   TTS_VOICE=Puck
หมายเหตุ: ชื่อรุ่น/โควตาฟรีของ Google เปลี่ยนบ่อย ถ้า error ให้บอก Claude "เช็ครุ่น Gemini TTS ล่าสุด"
"""
import base64, json, os, sys, time, urllib.error, urllib.request, wave
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import env

KEY = env("GEMINI_API_KEY")
if not KEY:
    raise SystemExit("ไม่พบ GEMINI_API_KEY ใน .env")
MODEL = env("TTS_MODEL", "gemini-3.8-flash-tts")
VOICE = env("TTS_VOICE", "Puck")
STYLE = env("TTS_STYLE", "")  # โน้ตกำกับเป็นภาษาอังกฤษ เช่น "Read in a lively, friendly storytelling tone"


def synth(text):
    body = {"contents": [{"parts": [{"text": f"{STYLE}: {text}" if STYLE else text}]}],
            "generationConfig": {"responseModalities": ["AUDIO"],
                                 "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": VOICE}}}}}
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent"
    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json", "x-goog-api-key": KEY})
    for attempt in range(3):
        try:
            r = json.loads(urllib.request.urlopen(req, timeout=300).read())
        except urllib.error.HTTPError as e:
            msg = e.read().decode()[:300]
            if e.code == 429:
                raise SystemExit("โควตา TTS วันนี้หมดแล้ว (429) — รอรีเซ็ตพรุ่งนี้ หรือเปิด billing ใน AI Studio\n" + msg)
            raise SystemExit(f"HTTP {e.code}: {msg}")
        cand = r.get("candidates", [{}])[0]
        if "content" in cand:
            part = cand["content"]["parts"][0]["inlineData"]
            rate = int(part.get("mimeType", "rate=24000").split("rate=")[-1].split(";")[0] or 24000)
            return base64.b64decode(part["data"]), rate
        print("  API ตอบว่าง ลองใหม่…"); time.sleep(8)
    raise SystemExit("API ตอบว่าง 3 ครั้ง ลองใหม่ภายหลัง")


def write_wav(path, pcm, rate):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(pcm)


def trim_noise_tail(pcm):
    """บางครั้ง TTS แถมเสียงซ่าดังผิดปกติท้ายไฟล์ → ตัดทิ้ง"""
    import array
    a = array.array("h", pcm)
    win = 2400
    for i in range(len(a) - win, 0, -win):
        seg = a[i:i + win]
        if max(abs(x) for x in seg) < 30000:
            return a[:i + win].tobytes()
    return pcm


def split_on_silences(pcm, rate, n):
    """หาช่วงเงียบที่ยาวที่สุด n-1 ช่วง แล้วหั่นตรงกลาง (ใช้กับการเจนรวมหลายบท)"""
    import array
    a = array.array("h", pcm); hop = rate // 50  # 20ms
    quiet = [max(abs(x) for x in a[i:i + hop]) < 500 for i in range(0, len(a), hop)]
    runs, s = [], None
    for i, q in enumerate(quiet + [False]):
        if q and s is None: s = i
        if not q and s is not None: runs.append((i - s, s, i)); s = None
    cuts = sorted(sorted(runs, reverse=True)[:n - 1], key=lambda r: r[1])
    pts = [0] + [((s + e) // 2) * hop for _, s, e in cuts] + [len(a)]
    return [a[pts[i]:pts[i + 1]].tobytes() for i in range(n)]


clips = [os.path.abspath(c) for c in sys.argv[1:]]
if not clips:
    raise SystemExit(__doc__)
scripts = [open(os.path.join(c, "script.txt"), encoding="utf-8").read().strip() for c in clips]
text = "\n\n\n".join(s.replace("\n", " ") for s in scripts)
print(f"เจนเสียง {len(clips)} บท · {len(text)} ตัวอักษร · รุ่น {MODEL} · เสียง {VOICE}")
pcm, rate = synth(text)
pcm = trim_noise_tail(pcm)
parts = [pcm] if len(clips) == 1 else split_on_silences(pcm, rate, len(clips))
for c, p in zip(clips, parts):
    out = os.path.join(c, "vo", "vo.wav")
    write_wav(out, p, rate)
    print(f"  ✓ {out}  ({len(p) / rate / 2:.1f} วิ)")
if len(clips) > 1:
    print("⚠️ เจนรวมแล้วหั่นอัตโนมัติ — ฟังต้น/ท้ายทุกไฟล์ว่าคำไม่ข้ามไปอีกคลิป")
